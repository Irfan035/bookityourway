<?php

$images_array = [
    "HAC2" => 'https://bookityourway.resvoyage.com/Content/hotel-logos/Amenities-Banner/HAC2.png',
    "HAC8" => 'https://bookityourway.resvoyage.com/Content/hotel-logos/Amenities-Banner/HAC8.png',
    "HAC20" => 'https://bookityourway.resvoyage.com/Content/hotel-logos/Amenities-Banner/HAC20.png',
    "HAC24" => 'https://bookityourway.resvoyage.com/Content/hotel-logos/Amenities-Banner/HAC24.png',
    "HAC26" => 'https://bookityourway.resvoyage.com/Content/hotel-logos/Amenities-Banner/HAC26.png',
    "HAC42" => 'https://bookityourway.resvoyage.com/Content/hotel-logos/Amenities-Banner/HAC42.png',
    "HAC53" => 'https://bookityourway.resvoyage.com/Content/hotel-logos/Amenities-Banner/HAC53.png',
    "HAC58" => 'https://bookityourway.resvoyage.com/Content/hotel-logos/Amenities-Banner/HAC58.png',
    "HAC66" => 'https://bookityourway.resvoyage.com/Content/hotel-logos/Amenities-Banner/HAC66.png',
    "HAC71" => 'https://bookityourway.resvoyage.com/Content/hotel-logos/Amenities-Banner/HAC71.png',
    "HAC76" => 'https://bookityourway.resvoyage.com/Content/hotel-logos/Amenities-Banner/HAC76.png',
    "HAC77" => 'https://bookityourway.resvoyage.com/Content/hotel-logos/Amenities-Banner/HAC77.png',
    "HAC78" => 'https://bookityourway.resvoyage.com/Content/hotel-logos/Amenities-Banner/HAC78.png',
    "HAC84" => 'https://bookityourway.resvoyage.com/Content/hotel-logos/Amenities-Banner/HAC84.png',
    "HAC97" => 'https://bookityourway.resvoyage.com/Content/hotel-logos/Amenities-Banner/HAC97.png',
    "HAC165" => 'https://bookityourway.resvoyage.com/Content/hotel-logos/Amenities-Banner/HAC165.png',
    "HAC178" => 'https://bookityourway.resvoyage.com/Content/hotel-logos/Amenities-Banner/HAC178.png',
    "HAC198" => 'https://bookityourway.resvoyage.com/Content/hotel-logos/Amenities-Banner/HAC198.png',
    "HAC218" => 'https://bookityourway.resvoyage.com/Content/hotel-logos/Amenities-Banner/HAC218.png',
    "PHY50" => 'https://bookityourway.resvoyage.com/Content/hotel-logos/Amenities-Banner/PHY50.png',
    "SEC34" => 'https://bookityourway.resvoyage.com/Content/hotel-logos/Amenities-Banner/SEC34.png'
];

?>