<?php


$CheckInDate_Jamaica = $_GET['check_in_date'] ? date("Y-m-d", strtotime($_GET['check_in_date'])) : date("Y-m-d");

$tomorrowUnix = strtotime("+2 day");
$CheckoutDate_Jamaica = $_GET['check_out_date'] ? date("Y-m-d", strtotime($_GET['check_out_date'])) : date("Y-m-d", $tomorrowUnix);

$checkInPlusOneUnix = strtotime($CheckoutDate_Jamaica);
$checkInPlusOneUnix = strtotime("-1 day",$checkInPlusOneUnix);
$checkInPlusOneUnix_destination = date("Y-m-d", $checkInPlusOneUnix);

$property = $atts['destination'];
echo '<input type="hidden" id="smoobu_single_property_id" value="' . $property . '">';
?>
<form action="" method="get">
    <?php
    echo '
            <div class="row shadow bg-light my-3 py-2 px-3 border border-5 border-white">
                <div class="col d-flex justify-content-center">
                    <input type="date" name="check_in_date" class="form-control" id="checkin_calander" onfocus="this.showPicker()" placeholder="Check In Date" aria-label="Check In Date" min="'.$CheckInDate_Jamaica.'" max="'.$checkInPlusOneUnix_destination.'" value="'.$CheckInDate_Jamaica.'" required>
                </div>
                <div class="col d-flex justify-content-center">
                    <input type="date" name="check_out_date" class="form-control" id="checkout_calander" onfocus="this.showPicker()" placeholder="Check Out Date" aria-label="Check Out Date" min="'.$checkInPlusOneUnix_destination.'" value="'.$CheckoutDate_Jamaica.'" required>
                </div>
                <div class="col">
                    <input type="submit" class="button button-danger w-100" value="Search">
                </div>
            </div>
    ';
    ?>
</form>
<?php

// $HotelCityCode ;

// //Print it out
// echo $CheckoutDate;

// $Adults = 1;
// $RoomCount = 1;
// $PlaceId ="ChIJCzYy5IS16lQRQrfeQ5K5Oxw"; 
$urlToken = 'https://rest.resvoyage.com/api/v1/public/token?clientname=Book It Your Way';
// $token_url= add_query_arg($urlToken);
$tokenValue = wp_remote_get($urlToken);
$response_token = json_encode($tokenValue, true);
$formated_token = json_decode($response_token, true);
$new_token = json_decode($formated_token['body'], true)['Token'];
$headers_HS = array(
    'Authorization' => 'Bearer ' . $new_token
);
$destiation_url = 'https://rest.resvoyage.com/api/v1/hotel/references/destination/' . $property;
$response_DS = wp_remote_get(
    $destiation_url,
    array(
        'headers' => $headers_HS
    )
);
// $hotel_place_id = ''
$hotel_res = wp_remote_retrieve_body($response_DS);
$hotel_DS_res = json_decode($hotel_res, true);
//deCondition for PlaceId
$found = false;
foreach ($hotel_DS_res as $hotel_DS_name) {
    $DS_name = $hotel_DS_name['Name'];
    //echo $DS_name;
    if (strtolower($DS_name) == $property) {
        $found = true;
        $DS_placeID = $hotel_DS_name['PlaceId'];
        break; // Exit the loop once a match is found
    }
}

if (!$found) {
    echo "Destination Not there";
}

$url_HS = 'https://rest.resvoyage.com/api/v1/hotel/search';

$params_HS = array(
    'HotelCityCode' => '',
    'CheckInDate' => $CheckInDate_Jamaica,
    'CheckoutDate' => $CheckoutDate_Jamaica,
    'Adults' => '1',
    'RoomCount' => '1',
    'PlaceId' => $DS_placeID // Its the Jmaica Place
);
$request_url_HS = add_query_arg($params_HS, $url_HS);
// echo $request_url_HS . "<br><br>";
$response_HS = wp_remote_get(
    $request_url_HS,
    array(
        'timeout' => 15,
        'headers' => $headers_HS
    )
);

if (is_wp_error($response_HS)) {
    // Handle error
    $error_message = $response_HS->get_error_message();
    echo "Error: " . $error_message . "<br>";
} else {
    $response_HS_code = wp_remote_retrieve_response_code($response_HS);
    $response_HS_body = wp_remote_retrieve_body($response_HS);

    // Process the response based on the response code
    if ($response_HS_code == 200) {
        // Successful request
        $JmaicaHotels = json_decode($response_HS_body, true);
        // print_r($JmaicaHotels);
        $hotels = $JmaicaHotels['Hotels'];

        $current_page = isset($_GET['page']) ? intval($_GET['page']) : 1;
        // echo  $current_page . "<br>";
        $items_per_page = 10;
        $total_pages = ceil(count($hotels) / $items_per_page);
        // echo  $total_pages . "<br>";
        $start_index = ($current_page - 1) * $items_per_page;
        // echo  $start_index . "<br>";
        $current_page_hotels = array_slice($hotels, $start_index, $items_per_page);
        //  echo $current_page_hotels . "<br>";


        echo '<div id="JmaicaHotelsContent" class="paginatin">';
        foreach ($current_page_hotels as $hotel): ?>

            <div class="row shadow bg-light my-2 p-0">
                <div class="col-md-3 d-flex justify-content-center">
                    <img src="<?php echo $hotel['HotelMainImage'] ? $hotel['HotelMainImage'] : plugins_url('/../includes/img/hotel.png.gif', __FILE__); ?>"
                        class="img-fluid" alt="Jmaica">
                </div>
                <div class="col-md-6">
                    <div class="border-bottom px-2 py-3 capitalize"
                        onclick="API.HotelDetails('16928f4b-5508-4059-bc07-dfffba5dd4cc')">
                        <span>
                            <strong>
                                <?php echo $hotel['HotelName']; ?>
                            </strong>
                            <br>
                            <?php for ($i = 0; $i < 3; $i++) { ?>
                                <i class="fa fa-star" style="font-size:0.8em"></i>
                            <?php } ?>
                        </span>
                    </div>
                    <div class="border-bottom px-2 py-3">
                        <i class="fa fa-calendar"></i>
                        <?php echo date('m/d/y', strtotime($hotel['CheckInDate'])); ?>
                        <i class="fa fa-calendar" style="margin-left:1.5em"></i>
                        <?php echo date('m/d/y', strtotime($hotel['CheckOutDate'])); ?>
                    </div>
                    <div class="border-bottom px-2 py-3" onclick="API.HotelShowOnMap('16928f4b-5508-4059-bc07-dfffba5dd4cc')">
                        <i class="fa fa-map-marker"></i>
                        <span style="text-transform: capitalize">
                            <?php echo $hotel['HotelAddress']['StreetAddress'] . " " . $hotel['HotelAddress']['CityName']; ?>
                        </span>
                    </div>

                </div>
                <div class="col-md-3 border p-3 d-flex justify-content-center">
                    <div class="text-center">
                        <h2 style="line-height: 1.2; margin: 0;">
                            <?php echo "$ " . $hotel['DailyRatePerRoom']; ?>
                        </h2>
                        <span style="font-size:0.7em; line-height: 0.21;">
                            Price per night<br>
                            Taxes not included
                        </span>
                        <button class="light-blue" id="SelectBtn"
                            onclick="GetRoomInfo('16928f4b-5508-4059-bc07-dfffba5dd4cc', this, 'MBJ', 'HS', 'ACZ', 'ACZ-HS-230614-230617' )"
                            style="width:100%;">
                            Select
                        </button>
                        <a href="javascript:;" class="ui" style="padding: 5px; cursor: pointer;"
                            onclick="API.HotelDetails('16928f4b-5508-4059-bc07-dfffba5dd4cc')">
                            Details
                            <i class="down chevron icon"></i>
                        </a>

                    </div>
                </div>
            </div>

        <?php endforeach;
        // print_r($hotels);
        echo '</div>';
        $Previous = $current_page - 1;
        $Next = $current_page + 1;
        // ---------------------------------add pagination----------------------------------
        echo '<div>';
        echo '<nav aria-label="Page navigation">';
        echo '<ul id="jamaica_pagination" class="pagination justify-content-center">';

        // Display the previous page link
        if ($current_page > 1) {
            echo '<li class="page-item"><a class="page-link" href="?page=' . $Previous .  '&check_in_date=' . $CheckInDate_Jamaica . '&check_out_date=' . $CheckoutDate_Jamaica . '" aria-label="Previous">
            <span aria-hidden="true">&laquo; Previous</span></a></li>';
        } else {
            echo '<li class="page-item disabled"><a class="page-link" href="?page=' . $Previous .  '&check_in_date=' . $CheckInDate_Jamaica . '&check_out_date=' . $CheckoutDate_Jamaica . '"><span aria-hidden="true">&laquo; Previous</span></a></li></a></li>';
        }

        // Display the numbered page links
        for ($i = 1; $i <= $total_pages; $i++) {
            if ($i === $current_page) {
                echo '<li class="page-item active"><a class="page-link" href="?page=' . $i .  '&check_in_date=' . $CheckInDate_Jamaica . '&check_out_date=' . $CheckoutDate_Jamaica . '">' . $i .'</a></li>';
            } else {
                echo '<li class="page-item"><a class="page-link" href="?page=' . $i .  '&check_in_date=' . $CheckInDate_Jamaica . '&check_out_date=' . $CheckoutDate_Jamaica . '" >' . $i . '</a></li>';
            }
        }

        // Display the next page link
        if ($current_page < $total_pages) {
            echo '<li class="page-item"><a class="page-link" href="?page=' . $Next . '&check_in_date=' . $CheckInDate_Jamaica . '&check_out_date=' . $CheckoutDate_Jamaica . '" aria-label="Next"><span aria-hidden="true">Next &raquo;</span></a></li>';

        } else {
            echo '<li class="page-item disabled"><a class="page-link" href="?page=' . $Next .  '&check_in_date=' . $CheckInDate_Jamaica . '&check_out_date=' . $CheckoutDate_Jamaica . '"> <span aria-hidden="true">Next &raquo;</span></a></li>';
        }

        echo '</ul>';
        echo '</nav>';
        echo '</div>';

    } else {
        // Handle non-200 response
        echo '<div class="bg-light shadow text-center p-5 border border-5 border-white">
            <p class="my-5">Hotel information not available.</p>

        </div>';
    }
}

?>
<script>
    jQuery(document).ready(function($){
        jQuery('#checkout_calander').change(function() {
            var date = $(this).val();
            console.log(date, 'change');
            jQuery("#checkin_calander").attr({
                "max" : date
            });
        });
    });

</script>